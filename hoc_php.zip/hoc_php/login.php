
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng Nhập</title>
</head>
<body>
    <div style="width:50%; margin-left:25%;">
        <form action="xlloggin.php" method="POST">
            Name:<input type="text" name="user" value="admin">
            <br>
            Pass:<input type="password" name="pass" value="123456">
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
