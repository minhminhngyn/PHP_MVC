<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh mục sản phẩm</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }
        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #000;
            overflow-x: hidden;
        }
        .sidenav a {
            color: white;
            padding: 16px;
            text-decoration: none;
            display: block;
        }
        .sidenav a:hover {
            background-color: #ddd;
            color: black;
        }
        .content {
            margin-left: 200px;
            padding-left: 20px;
        }
        .product-grid {
            margin-left: 200px;
            margin-top: 30px;
            padding-left: 20px;
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
        }
        .product {
            border: 0.2px solid #000;
            padding: 10px;
            text-align: left;
            width: 230px;
            cursor: pointer; 
        }
        .product {
        cursor: pointer;
        transition: background-color 0.3s;
        }
        .product.selected {
        background-color: #f0f8ff;
        border: 2px solid #007BFF; 
        }
        .product a {
            display: block;
            text-align: right;
            margin-top: 10px; 
        }
        .product .image {
            width: 100%;
            height: 150px;
            background-color: #f0f0f0;
            margin-bottom: 10px;
        }
        .pagination {
            margin-top: 20px;
            text-align: center;
        }
        .pagination a {
            text-decoration: none;
            margin: 0 5px;
            color: #000;
        }
        .actions {
            margin: 20px;
            text-align: center;
        }
        .actions button {
            padding: 10px 20px;
            margin: 5px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .actions button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="content">
        <h2>Danh mục sản phẩm</h2>
    </div>
    
    <div class="sidenav">
        <?php
        include("connect.php");
        $sql = "SELECT * FROM loaisp";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                echo '<a href="?Maloai=' . $row["Maloai"] . '">' . $row["Tenloai"] . '</a>';
            }
        } else {
            echo '<p>Không có loại sản phẩm nào.</p>';
        }
        ?>
    </div>
    <div class="product-grid">
        <?php
        $each_record = 2; 
        $page = 1;
        if (isset($_GET['page'])) {
            $page = $_GET['page']; 
        }
        $offset = ($page - 1) * $each_record; 
        if (isset($_GET['Maloai'])) {
            $maloai = mysqli_real_escape_string($conn, $_GET['Maloai']);
            $total_sql = "SELECT COUNT(*) as total FROM sanpham WHERE Maloai = '$maloai'";
            $sql = "SELECT * FROM sanpham WHERE Maloai = '$maloai' LIMIT $each_record OFFSET $offset";
        } else {
            $total_sql = "SELECT COUNT(*) as total FROM sanpham";
            $sql = "SELECT * FROM sanpham LIMIT $each_record OFFSET $offset";
        }
        $total_result = mysqli_query($conn, $total_sql);
        $total_row = mysqli_fetch_assoc($total_result);
        $total_record = $total_row['total']; 
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                echo '<div class="product" onclick="selectProduct(this)" data-id="' . $row["Mahang"] . '">';
                echo '<div class="image"></div>';
                echo '<p>' . $row["Tenhang"] . '</p>';
                echo '<p>Giá: $' . $row["Giahang"] . '</p>';
                echo '<p>SL: ' . $row["Soluong"] . '</p>';
                echo '<p>Mô tả: ' . $row["Mota"] . '</p>';
                echo '</div>';
            }
        } else {
            echo "Không có sản phẩm nào.";
        }
        ?>
    </div>

    <div class="pagination">
        <?php
        $total_page = ceil($total_record / $each_record);
        for ($i = 1; $i <= $total_page; $i++) {
            echo "<a href='?page=$i";
            if (isset($_GET['Maloai'])) {
                echo "&Maloai=" . $_GET['Maloai']; 
            }
            echo "'>$i</a> ";
        }
        $conn->close();
        ?>
    </div>
    <div class="actions">
    <button onclick="xoa()">Xóa</button>
    <button onclick="sua()">Sửa</button>
</div>

<script>
    let selectedProduct = null;

    function selectProduct(element) {
        if (selectedProduct) {
            selectedProduct.classList.remove('selected');
        }
        selectedProduct = element; 
        selectedProduct.classList.add('selected');
    }

    function xoa() {
        if (selectedProduct) {
            const maHang = selectedProduct.getAttribute('data-id');
            if (confirm("Bạn có chắc chắn muốn xóa sản phẩm này?")) {
                window.location.href = `xoasp.php?Mahang=${maHang}`;
            }
        } else {
            alert("Vui lòng chọn một sản phẩm để xóa.");
        }
    }

    function sua() {
        if (selectedProduct) {
            const maHang = selectedProduct.getAttribute('data-id');
            window.location.href = `suasp.php?Mahang=${maHang}`;
        } else {
            alert("Vui lòng chọn một sản phẩm để sửa.");
        }
    }
</script>

</body>
</html>
