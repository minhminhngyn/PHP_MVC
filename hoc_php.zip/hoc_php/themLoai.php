<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="xlthemLoai.php" method="POST">
        Mã loại:<input type="text" name="Maloai" value=""><br>
        Tên loại:<input type="text" name="Tenloai" value=""><br>
        Mô tả:<input type="text" name="Mota" value=""><br>
        <input type="Submit" value="Thêm"><input type="reset" value="Nhập lại">
    </form>
</body>
</html>